package strCheck;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class strCheck {
    public static boolean nameCheck(String s){
        if(s.length()<5||s.length()>10)
            return false;
        else {
            String pattern1 = "^[a-zA-Z][a-zA-Z\\d_]*";
            String pattern2 = ".*[A-Z].*";
            boolean match1 = Pattern.matches(pattern1, s);
            boolean match2 = Pattern.matches(pattern2, s);
            if(match1 && match2)
                return true;
            else
                return false;
        }
    }


    public static boolean passCheck(String s){
        if(s.length()<6||s.length()>12)
            return false;
        else{
            Pattern p = Pattern.compile("[a-zA-Z0-9'_']+");
            Matcher m = p.matcher(s);
            return m.matches();
        }
    }
    public static boolean ageCheck(String s) {
        String pattern4 = "^([1-9]\\d|\\d)$";
        boolean match4 = Pattern.matches(pattern4, s);
        if (!(s.isEmpty())&&!match4) {
            return false;
        }
        else{
            return true;
        }
    }
    public static boolean teleCheck(String s) {
        String pattern4 = "[1][3578]\\d{9}";
        boolean match4 = Pattern.matches(pattern4, s);
        if (!(s.isEmpty())&&!match4) {
            return false;
        }
        else{
            return true;
        }
    }

}
