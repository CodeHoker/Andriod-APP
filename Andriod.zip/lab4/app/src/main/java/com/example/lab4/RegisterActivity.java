package com.example.lab4;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import strCheck.strCheck;

public class RegisterActivity extends AppCompatActivity {
    private EditText reg_username;
    private EditText reg_password;
    private EditText reg_password2;
    private EditText name;
    private EditText age;
    private EditText teleno;
    private TextView err;
    private Button reg_btn_sure;
    private Button reg_btn_login;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        err = (TextView) findViewById(R.id.message);
        reg_username = (EditText) findViewById(R.id.u1);
        reg_password = (EditText) findViewById(R.id.pw1);
        reg_password2 = (EditText) findViewById(R.id.pw2);
        name=(EditText) findViewById(R.id.n1);
        age=(EditText) findViewById(R.id.a1);
        teleno=(EditText) findViewById(R.id.t1);
        reg_btn_sure = (Button) findViewById(R.id.button3);
        reg_btn_login = (Button) findViewById(R.id.button4);
        reg_btn_sure.setOnClickListener(new RegisterButton());
        reg_btn_login.setOnClickListener(new RegisterButton());
    }
    public class RegisterButton implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            String username = reg_username.getText().toString().trim();
            String password = reg_password.getText().toString().trim();
            String password2 = reg_password2.getText().toString().trim();
            String name1=name.getText().toString().trim();
            String age1=age.getText().toString().trim();
            String teleno1=teleno.getText().toString().trim();
            switch (v.getId()) {
                //注册开始，判断注册条件
                case R.id.button3:
                    if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password) || TextUtils.isEmpty(password2)||TextUtils.isEmpty(name1)) {
                        Toast.makeText(RegisterActivity.this, "除了电话年龄其他均不能为空", Toast.LENGTH_SHORT).show();
                    } else {
                        if(username.length()<5 || username.length()>10)
                            Toast.makeText(RegisterActivity.this,"用户名长度必须为5至10位",Toast.LENGTH_SHORT).show();
                        if(!strCheck.nameCheck(username))
                            Toast.makeText(RegisterActivity.this,"用户名不合法",Toast.LENGTH_SHORT).show();
                            reg_username.setText(null);
                        if(!strCheck.passCheck(password)){
                            Toast.makeText(RegisterActivity.this,"密码不合法",Toast.LENGTH_SHORT).show();
                            reg_password.setText(null);
                        }
                        if (!(TextUtils.equals(password, password2))) {
                            Toast.makeText(RegisterActivity.this,"两次输入的密码不一样",Toast.LENGTH_SHORT).show();
                            reg_password2.setText(null);
                        }
                        if(!(strCheck.ageCheck(age1))){
                            Toast.makeText(RegisterActivity.this,"年龄不合法",Toast.LENGTH_SHORT).show();
                            age.setText(null);
                        }
                        if(!(strCheck.teleCheck(teleno1))){
                            Toast.makeText(RegisterActivity.this,"电话号码不合法",Toast.LENGTH_SHORT).show();
                            teleno.setText(null);
                        }
                        if((strCheck.nameCheck(username)) && (strCheck.passCheck(password)) && (TextUtils.equals(password, password2)) &&(strCheck.teleCheck(teleno1)) &&(strCheck.ageCheck(age1)))
                        {
                            System.out.println("success");
                            new SignInProcess().execute(username, password, name1, age1, teleno1);
                        }

                    }
                    break;
                case R.id.button4:
                    Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                    startActivity(intent);
                    break;
            }
        }
    }
    private class SignInProcess extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... params) {
            String username = params[0];
            String password = params[1];
            String name = params[2];
            String age= params[3];
            String teleno = params[4];
            String result = "";
            String s_url = "http://192.168.15.143:8080/MysqlNetSystem/registerServlet?username="+username+"&name="+name+"&age="+age+"&teleno="+teleno+"&password="+password;
            System.out.println(s_url);
            System.out.println(s_url+" "+username+" "+password+" "+name+" "+age+" "+teleno);
            try {
                System.out.println("get");
                URL url = new URL(s_url);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setUseCaches(false);
                conn.connect();
                InputStream is = conn.getInputStream();
                InputStreamReader reader = new InputStreamReader(is, "UTF-8");//获取服务器数据实现从字节流到字符流转换
                int temp;
                while((temp=reader.read()) != -1) {
                    result += (char)temp;
                }
            } catch(Exception e) {
                err.setText("登录失败，网络错误");
                err.setVisibility(View.VISIBLE);

                e.printStackTrace();
            }
            System.out.println(result);
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                JSONObject result_json = new JSONObject(result);
                if(result_json.has("error")) {
                    String error_code;
                    error_code = result_json.getString("error");
                    err.setText(error_code);
                    err.setVisibility(View.VISIBLE);
                    Toast.makeText(RegisterActivity.this,error_code,Toast.LENGTH_SHORT).show();
                    name.setText(null);
                } else {
                    SignInSuccess(result_json);
                }

            } catch (Exception e) {

                e.printStackTrace();
            }
        }

    }

    private void SignInSuccess(JSONObject info) throws JSONException {
        Intent intent=new Intent();
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setClass(this,WelcomeActivity.class);
        System.out.println(info.getString("username"));
        Toast.makeText(this,"注册成功",Toast.LENGTH_SHORT).show();

        try {
            intent.putExtra("username1", info.getString("name"));
            intent.putExtra("username", info.getString("username"));
            intent.putExtra("name", info.getString("name"));
            intent.putExtra("age", info.getString("age"));
            intent.putExtra("teleno", info.getString("teleno"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        startActivity(intent);
    }
}

