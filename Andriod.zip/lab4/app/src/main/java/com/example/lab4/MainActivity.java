package com.example.lab4;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private EditText et_username;
    private EditText et_password;
    private TextView err;
    private Button btn_login;
    private Button btn_register;
    private boolean flag=true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Map<String, String> userInfo = null;//SaveInfo.getSaveInformation(this);
        if (userInfo != null) {
            et_username.setText(userInfo.get("username"));
            et_password.setText(userInfo.get("password"));
        }
        et_username =(EditText) findViewById(R.id.et1);
        et_password =(EditText) findViewById(R.id.et2);
        btn_login =(Button) findViewById(R.id.button1);
        err = (TextView) findViewById(R.id.message);
        btn_register =(Button) findViewById(R.id.button2);
        btn_login.setOnClickListener(new MyButton());
        btn_register.setOnClickListener(new MyButton());
    }

    public  class MyButton implements View.OnClickListener{
        @Override
        public void onClick(View view){
            String username =et_username.getText().toString().trim();
            String password =et_password.getText().toString().trim();
            switch (view.getId()) {
                //当点击登录按钮时
                case R.id.button1:
                    if(TextUtils.isEmpty(username) || TextUtils.isEmpty(password)){
                        Toast.makeText(MainActivity.this,"密码或账号不能为空",Toast.LENGTH_SHORT).show();
                    } else {
                        new SignInProcess().execute(username,password);
                    }
                    break;
                //当点击注册按钮事件时
                case R.id.button2:
                    Intent intent = new Intent(MainActivity.this,RegisterActivity.class);
                    startActivity(intent);
                    break;
            }
        }
    }
    private class SignInProcess extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... params) {
            String username = params[0];
            String password = params[1];
            String result = "";
            String s_url = "http://192.168.15.143:8080/MysqlNetSystem/loginservlet?username="+username+"&password="+password;
            System.out.println(s_url);
            System.out.println(s_url+" "+username+" "+password);
            try {
                URL url = new URL(s_url);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setUseCaches(false);
                conn.connect();
                InputStream is = conn.getInputStream();
                InputStreamReader reader = new InputStreamReader(is, "UTF-8");//获取服务器数据实现从字节流到字符流转换
                int temp;
                while((temp=reader.read()) != -1) {
                    result += (char)temp;
                }
            } catch(Exception e) {
                err.setText("登录失败，网络错误");
                err.setVisibility(View.VISIBLE);
                flag=false;
                e.printStackTrace();
            }
            System.out.println(result);
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                JSONObject result_json = new JSONObject(result);
                if(result_json.has("error")) {
                    String error_code;
                    error_code = result_json.getString("error");
                    err.setText(error_code);
                    err.setVisibility(View.VISIBLE);
                    Toast.makeText(MainActivity.this,error_code,Toast.LENGTH_SHORT).show();
                    et_password.setText(null);
                    flag=false;
                } else {
                    flag=true;
                    SignInSuccess(result_json);
                }

            } catch (Exception e) {
                flag=false;
                e.printStackTrace();
            }
        }

    }

    private void SignInSuccess(JSONObject info) throws JSONException {
        Intent intent=new Intent();
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setClass(this,WelcomeActivity.class);
        System.out.println(info.getString("username")+flag);

        Toast.makeText(this,"登录成功",Toast.LENGTH_SHORT).show();

        try {
            intent.putExtra("username1", info.getString("name"));
            intent.putExtra("username", info.getString("username"));
            intent.putExtra("name", info.getString("name"));
            intent.putExtra("age", info.getString("age"));
            intent.putExtra("teleno", info.getString("teleno"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        startActivity(intent);
    }



}

